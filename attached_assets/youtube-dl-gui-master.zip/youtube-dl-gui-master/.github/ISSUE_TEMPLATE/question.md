---
name: Question
about: Ask a question about youtube-dl-gui
title: ''
labels: question
assignees: ''

---

**Is your question related to a problem? Please describe.**
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]

**Describe the question you have.**
A clear and concise question about youtube-dl-gui.

**Additional context**
Add any other context or screenshots about the question here.
